package com.avengers.ai.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.avengers.ai.AppContainer
import com.avengers.ai.data.Message
import com.avengers.ai.data.Mode
import com.avengers.ai.data.Session
import com.avengers.ai.voice.VoiceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

inline fun <reified T : ViewModel> vmFactory(crossinline build: () -> T): ViewModelProvider.Factory =
    object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <V : ViewModel> create(modelClass: Class<V>): V = build() as V
    }

class HomeViewModel(private val c: AppContainer) : ViewModel() {
    fun hasKey() = c.settings.hasKey()
}

class ChatViewModel(private val c: AppContainer, private val mode: Mode, initialSid: String?) : ViewModel() {
    private val sid = MutableStateFlow(initialSid ?: c.store.latest(mode)?.id ?: c.store.create(mode).id)

    val messages: StateFlow<List<Message>> =
        combine(sid, c.store.sessions) { id, list -> list.firstOrNull { it.id == id }?.messages ?: emptyList() }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val busy = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy.value) return
        busy.value = true
        error.value = null
        viewModelScope.launch {
            c.repo.send(sid.value, t, mode).onFailure { error.value = it.message }
            busy.value = false
        }
    }

    fun newChat() { sid.value = c.store.create(mode).id; error.value = null }
}

enum class VState { IDLE, LISTENING, THINKING }

data class VoiceUi(
    val state: VState = VState.IDLE,
    val heard: String = "",
    val reply: String = "",
    val error: String? = null
)

class VoiceViewModel(private val c: AppContainer) : ViewModel() {
    private val engine = VoiceEngine(c.appContext)
    private val sid = c.store.latest(Mode.VOICE)?.id ?: c.store.create(Mode.VOICE).id

    val ui = MutableStateFlow(VoiceUi())
    val level = engine.level
    val speaking = engine.speaking

    fun startListening() {
        engine.stopSpeaking()
        ui.update { it.copy(state = VState.LISTENING, error = null) }
        engine.listen(
            c.settings.language,
            onResult = { text ->
                ui.update { it.copy(heard = text, state = VState.THINKING) }
                viewModelScope.launch {
                    c.repo.send(sid, text, Mode.VOICE).fold(
                        onSuccess = { r ->
                            ui.update { it.copy(state = VState.IDLE, reply = r.display) }
                            engine.speak(r.spoken, c.settings.language)
                        },
                        onFailure = { e -> ui.update { it.copy(state = VState.IDLE, error = e.message) } }
                    )
                }
            },
            onFail = { msg -> ui.update { it.copy(state = VState.IDLE, error = msg) } }
        )
    }

    fun stop() {
        engine.stopListening()
        engine.stopSpeaking()
        ui.update { it.copy(state = VState.IDLE) }
    }

    fun setError(msg: String) = ui.update { it.copy(error = msg, state = VState.IDLE) }

    override fun onCleared() { engine.shutdown() }
}

class PhoneViewModel(private val c: AppContainer) : ViewModel() {
    val result = MutableStateFlow("Koi action nahi chala abhi tak.")
    fun run(type: String, arg: String = "") {
        result.value = c.actions.execute(com.avengers.ai.phone.PhoneAction(type, arg))
    }
}

data class SettingsUi(
    val hasKey: Boolean,
    val model: String,
    val language: String,
    val persona: String,
    val testing: Boolean = false,
    val testResult: String? = null,
    val note: String? = null
)

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val ui = MutableStateFlow(
        SettingsUi(c.settings.hasKey(), c.settings.model, c.settings.language, c.settings.persona)
    )

    fun saveKey(key: String) {
        if (key.isBlank()) return
        c.settings.apiKey = key
        ui.update { it.copy(hasKey = true, note = "API key encrypted storage me save ho gayi.", testResult = null) }
    }

    fun removeKey() {
        c.settings.apiKey = ""
        ui.update { it.copy(hasKey = false, note = "API key hata di.", testResult = null) }
    }

    fun testConnection() {
        ui.update { it.copy(testing = true, testResult = null) }
        viewModelScope.launch {
            val r = c.provider.test()
            ui.update {
                it.copy(testing = false, testResult = r.fold({ m -> "✔ $m" }, { e -> "✘ ${e.message}" }))
            }
        }
    }

    fun setModel(m: String) { c.settings.model = m; ui.update { it.copy(model = c.settings.model) } }
    fun setLanguage(l: String) { c.settings.language = l; ui.update { it.copy(language = l) } }
    fun savePersona(p: String) { c.settings.persona = p; ui.update { it.copy(persona = c.settings.persona, note = "Personality save ho gayi.") } }
    fun setTheme(t: String) = c.settings.setTheme(t)
    fun clearHistory() { c.store.clearAll(); ui.update { it.copy(note = "Saari chat history delete ho gayi.") } }
}

class HistoryViewModel(private val c: AppContainer) : ViewModel() {
    val sessions: StateFlow<List<Session>> = c.store.sessions
        .map { list -> list.filter { it.messages.isNotEmpty() }.sortedByDescending { it.updated } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun delete(id: String) = c.store.delete(id)
}
